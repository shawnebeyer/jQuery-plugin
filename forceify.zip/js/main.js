$(function() {
	//Instructions
	//Your page wants to experience the force. It needs to. To make your
	//page happy, simply add .forceify(); to any html element. The plug-in
	//starts on a click, so why not start off with a link click?
	//Here's an example: $('.myButton').forceify();
	//May the 4th be with you.
	$('.forceify').forceify();
});